package dev.paintcraft.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.paintcraft.core.Decal;
import dev.paintcraft.projection.ResolvedSurface;
import dev.paintcraft.projection.SurfaceFragment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class DecalRenderer {

    private static final Map<UUID, ResolvedEntry> resolvedCache = new ConcurrentHashMap<>();

    private DecalRenderer() {}

    public static void cacheResolved(UUID decalId, Decal decal, ResolvedSurface resolved) {
        resolvedCache.put(decalId, new ResolvedEntry(decal, resolved));
    }

    public static void invalidate(UUID decalId) {
        resolvedCache.remove(decalId);
    }

    public static void invalidateAll() {
        resolvedCache.clear();
    }

    public static void renderAll(PoseStack poseStack, MultiBufferSource bufferSource, Vec3 cameraPos) {
        if (resolvedCache.isEmpty()) return;

        // TODO: use a proper cutout render type for alpha support
        VertexConsumer consumer = bufferSource.getBuffer(RenderType.translucent());

        for (ResolvedEntry entry : resolvedCache.values()) {
            Decal decal = entry.decal;
            ResolvedSurface resolved = entry.resolved;
            if (resolved.isEmpty()) continue;

            double distSq = cameraPos.distanceToSqr(Vec3.atCenterOf(decal.anchor()));
            // TODO: configurable max render distance
            if (distSq > 128 * 128) continue;

            for (SurfaceFragment frag : resolved.fragments()) {
                renderFragment(poseStack, consumer, decal, frag, cameraPos, distSq);
            }
        }
    }

    private static void renderFragment(PoseStack poseStack, VertexConsumer consumer,
                                        Decal decal, SurfaceFragment frag,
                                        Vec3 cameraPos, double distSq) {
        float[] verts = frag.vertices();
        Direction normal = frag.faceNormal();

        // adaptive z-offset: base + tier step
        float baseEpsilon = (float) (0.001 + Math.sqrt(distSq) * 0.00002);
        float tierStep = 0.00008f;
        float offset = baseEpsilon + frag.zTier() * tierStep;

        float nx = normal.getStepX() * offset;
        float ny = normal.getStepY() * offset;
        float nz = normal.getStepZ() * offset;

        poseStack.pushPose();
        // translate relative to camera
        Vec3 cam = cameraPos;
        poseStack.translate(-cam.x, -cam.y, -cam.z);

        Matrix4f matrix = poseStack.last().pose();
        int wPx = decal.widthPx();
        int[] pixels = decal.pixels();

        // emit one quad per pixel in this fragment's UV range
        // TODO: replace with batched rect-merged rendering for performance
        int pu0 = (int) frag.u0();
        int pv0 = (int) frag.v0();
        int pu1 = (int) frag.u1();
        int pv1 = (int) frag.v1();

        float fragWorldW = verts[3] - verts[0]; // approximate width extent
        float fragWorldH = verts[7] - verts[1]; // approximate height extent
        int fragPxW = pu1 - pu0 + 1;
        int fragPxH = pv1 - pv0 + 1;
        if (fragPxW <= 0 || fragPxH <= 0) return;

        float pxWorldW = fragWorldW / fragPxW;
        float pxWorldH = fragWorldH / fragPxH;

        for (int py = pv0; py <= pv1; py++) {
            for (int px = pu0; px <= pu1; px++) {
                int idx = py * wPx + px;
                if (idx < 0 || idx >= pixels.length) continue;
                int color = pixels[idx];
                int a = (color >> 24) & 0xFF;
                if (a <= 2) continue;

                float r = ((color >> 16) & 0xFF) / 255f;
                float g = ((color >> 8) & 0xFF) / 255f;
                float b = (color & 0xFF) / 255f;
                float af = a / 255f;

                // TODO: compute actual per-pixel world position from projection
                // This is a placeholder - real implementation needs to map
                // pixel (px, py) back to world-space quad corners within the fragment
                int light = LevelRenderer.getLightColor(
                    Minecraft.getInstance().level,
                    frag.pos().relative(frag.faceNormal())
                );

                // placeholder: skip actual vertex emission until render pipeline is complete
            }
        }

        poseStack.popPose();
    }

    private record ResolvedEntry(Decal decal, ResolvedSurface resolved) {}
}
