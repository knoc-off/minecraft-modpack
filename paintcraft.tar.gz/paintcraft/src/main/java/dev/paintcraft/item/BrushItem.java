package dev.paintcraft.item;

import dev.paintcraft.PaintCraft;
import dev.paintcraft.core.Decal;
import dev.paintcraft.network.DecalCreatePayload;
import dev.paintcraft.storage.ChunkPaintStorage;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

import java.util.Optional;
import java.util.UUID;

public class BrushItem extends Item {

    public BrushItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        BlockHitResult hit = getPlayerPOVHitResult(level, player, ClipContext.Fluid.NONE);
        if (hit.getType() != HitResult.Type.BLOCK) {
            return InteractionResultHolder.pass(held);
        }

        BlockPos pos = hit.getBlockPos();
        Direction face = hit.getDirection();
        BlockState state = level.getBlockState(pos);
        if (state.isAir()) return InteractionResultHolder.pass(held);

        boolean forceNew = player.isShiftKeyDown();

        if (level.isClientSide) {
            handleClient(pos, face, forceNew);
            return InteractionResultHolder.success(held);
        }

        if (level instanceof ServerLevel serverLevel) {
            handleServer(serverLevel, (ServerPlayer) player, pos, face, forceNew);
        }

        return InteractionResultHolder.success(held);
    }

    private void handleServer(ServerLevel level, ServerPlayer player, BlockPos pos, Direction face, boolean forceNew) {
        ChunkPaintStorage storage = ChunkPaintStorage.get(level, new net.minecraft.world.level.ChunkPos(pos));

        if (!forceNew) {
            Optional<Decal> existing = storage.getTopmostDecalAt(pos, face);
            if (existing.isPresent()) {
                // TODO: send existing decal data to client, open editor
                PaintCraft.LOGGER.debug("Edit existing decal {} at {}", existing.get().id(), pos);
                return;
            }
        }

        // create new 1x1 decal
        long seq = storage.nextSeqNo();
        Decal decal = Decal.singleFace(UUID.randomUUID(), seq, pos, face);
        decal.setAuthor(player.getGameProfile().getName());
        storage.putDecal(decal);
        PaintCraft.LOGGER.debug("Created decal {} at {} face {}", decal.id(), pos, face);
        // TODO: sync to client, open editor
    }

    private void handleClient(BlockPos pos, Direction face, boolean forceNew) {
        // TODO: if forceNew && no pending corner, start multi-block selection
        // TODO: if forceNew && pending corner, complete selection, open editor
        // TODO: otherwise, request server to open editor for existing/new decal
        PaintCraft.LOGGER.debug("Client brush use at {} face {} forceNew={}", pos, face, forceNew);
    }
}
