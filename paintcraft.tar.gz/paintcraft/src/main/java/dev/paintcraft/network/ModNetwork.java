package dev.paintcraft.network;

import dev.paintcraft.PaintCraft;
import dev.paintcraft.core.Decal;
import dev.paintcraft.storage.ChunkPaintStorage;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ChunkPos;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public final class ModNetwork {

    private static final String PROTOCOL_VERSION = "1";

    private ModNetwork() {}

    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar(PaintCraft.MODID)
            .versioned(PROTOCOL_VERSION);

        registrar.playToServer(
            DecalCreatePayload.TYPE,
            DecalCreatePayload.STREAM_CODEC,
            ModNetwork::handleDecalCreateOnServer
        );

        registrar.playToClient(
            DecalCreatePayload.TYPE,
            DecalCreatePayload.STREAM_CODEC,
            ModNetwork::handleDecalCreateOnClient
        );

        registrar.playBidirectional(
            DecalDeletePayload.TYPE,
            DecalDeletePayload.STREAM_CODEC,
            ModNetwork::handleDecalDelete
        );
    }

    private static void handleDecalCreateOnServer(DecalCreatePayload payload, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            ServerPlayer player = (ServerPlayer) ctx.player();
            ServerLevel level = player.serverLevel();
            ChunkPaintStorage storage = ChunkPaintStorage.get(level, new ChunkPos(payload.anchor()));

            Decal decal = new Decal(
                payload.id(), payload.seqNo(), payload.anchor(),
                payload.normal(), payload.up(),
                payload.widthPx(), payload.heightPx(), payload.depth(),
                payload.pixels(), payload.flags()
            );
            decal.setAuthor(player.getGameProfile().getName());
            storage.putDecal(decal);

            // TODO: broadcast to tracking players
            PaintCraft.LOGGER.debug("Server received decal {} from {}", decal.id(), player.getName().getString());
        });
    }

    private static void handleDecalCreateOnClient(DecalCreatePayload payload, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            // TODO: add to client-side decal cache, trigger resolve + render update
            PaintCraft.LOGGER.debug("Client received decal {}", payload.id());
        });
    }

    private static void handleDecalDelete(DecalDeletePayload payload, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            // TODO: remove from storage (server) or cache (client)
            PaintCraft.LOGGER.debug("Delete decal {}", payload.id());
        });
    }
}
